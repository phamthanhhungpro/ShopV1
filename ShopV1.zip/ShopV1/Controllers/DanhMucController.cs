﻿using Microsoft.AspNetCore.Mvc;
using ShopV1.Core.Repository;
using ShopV1.Core.UnitOfWork;
using ShopV1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopV1.Controllers
{
    public class DanhMucController : Controller
    {
        private readonly IEfRepository<DanhMuc> _danhMucRepository;
        private readonly IUnitOfWork _unitOfWork;

        /// <summary>
        /// Khởi tạo
        /// </summary>
        /// <param name="danhMucRepository"></param>
        /// <param name="unitOfWork"></param>
        public DanhMucController(IEfRepository<DanhMuc> danhMucRepository, IUnitOfWork unitOfWork)
        {
            _danhMucRepository = danhMucRepository;
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// View
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            var newModel = new DanhMuc()
            {
                Ten = "Laptop",
                IdParent = 0
            };

            Insert(newModel);

            var listDanhmuc = _danhMucRepository.TableNoTracking.ToList();

            if (!listDanhmuc.Any())
                return NoContent();

            return View(listDanhmuc);
        }

        /// <summary>
        /// Hàm thêm mới 1 danh mục, truyền vào model danh mục
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Insert(DanhMuc model)
        {
            if (string.IsNullOrEmpty(model.Ten))
                return BadRequest("Bạn phải nhập tên danh mục");

            _danhMucRepository.Insert(model);

            _unitOfWork.SaveChange();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hàm lấy dữ liệu tất cả bản ghi danh mục
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAll()
        {
            var listDanhmuc = _danhMucRepository.TableNoTracking.ToList();

            if (!listDanhmuc.Any())
                return NoContent();

            return View(listDanhmuc);
        }

        /// <summary>
        /// Hàm lấy dữ liệu tất cả bản ghi danh mục
        /// </summary>
        /// <returns></returns>
        [HttpGet("id")]
        public IActionResult GetById([FromQuery] int id)
        {
            var selectedModel = _danhMucRepository.TableNoTracking.Where(a => a.Id == id).FirstOrDefault();

            return View(selectedModel);
        }

        /// <summary>
        /// Hàm cập nhật dữ liệu bản ghi danh mục theo Id
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        public IActionResult Update([FromBody] DanhMuc model)
        {
            var selectedModel = _danhMucRepository.TableNoTracking.Where(a => a.Id == model.Id).FirstOrDefault();

            if (selectedModel == null)
                return BadRequest("Danh mục không tồn tại !");

            selectedModel.IdParent = model.IdParent;
            selectedModel.Ten = model.Ten;

            _danhMucRepository.Update(selectedModel);
            _unitOfWork.SaveChange();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Hàm cập xóa bản ghi danh mục theo Id
        /// </summary> 
        /// <returns></returns>
        [HttpDelete]
        public IActionResult Delete([FromQuery] int Id)
        {
            var selectedModel = _danhMucRepository.TableNoTracking.Where(a => a.Id == Id).FirstOrDefault();

            if (selectedModel == null)
                return BadRequest("Danh mục không tồn tại !");

            _danhMucRepository.Delete(selectedModel);
            _unitOfWork.SaveChange();

            return RedirectToAction("Index");
        }
    }
}
