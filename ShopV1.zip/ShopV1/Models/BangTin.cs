﻿using System;
using System.Collections.Generic;

namespace ShopV1.Models
{
    public partial class BangTin
    {
        public int Id { get; set; }
        public string Tieude { get; set; }
        public string Noidung { get; set; }
        public string Anhdaidien { get; set; }
    }
}
