﻿using System;
using System.Collections.Generic;

namespace ShopV1.Models
{
    public partial class AnhSanPham
    {
        public int Id { get; set; }
        public int? IdSanpahm { get; set; }
        public string Url { get; set; }
    }
}
