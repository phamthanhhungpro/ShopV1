﻿using System;
using System.Collections.Generic;

namespace ShopV1.Models
{
    public partial class DanhMuc
    {
        public int Id { get; set; }
        public int? IdParent { get; set; }
        public string Ten { get; set; }
    }
}
